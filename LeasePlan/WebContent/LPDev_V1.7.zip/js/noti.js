
    $(document).ready(function () {$('#noti_Counter').css({ opacity: 0 }).text('7').css({ top: '-10px' }).animate({ top: '-2px', opacity: 1 }, 500);$('#noti_Button').click(function () {$('#notifications').fadeToggle('fast', 'linear', function () {if ($('#notifications').is(':hidden')) {$('#noti_Button').css('background-color', '#ED8B00');}else $('#noti_Button').css('background-color', '#FFF');});$('#noti_Counter').fadeOut('slow'); return false;});$(document).click(function () {$('#notifications').hide();if ($('#noti_Counter').is(':hidden')) {$('#noti_Button').css('background-color', '#2E467C');}});$('#notifications').click(function () { return false; });});


    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-37088350-1']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
    (function () {
        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
        po.src = 'https://apis.google.com/js/plusone.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
    })();    


    $(document).ready(function () {$('#msg_Counter').css({ opacity: 0 }).text('4').css({ top: '-10px' }).animate({ top: '-2px', opacity: 1 }, 500);$('#msg_Button').click(function () {$('#notifications').fadeToggle('fast', 'linear', function () {if ($('#notifications').is(':hidden')) {$('#msg_Button').css('background-color', '#2E467C');}else $('#msg_Button').css('background-color', '#FFF');});$('#msg_Counter').fadeOut('slow'); return false;});$(document).click(function () {$('#notifications').hide();if ($('#msg_Counter').is(':hidden')) {$('#msg_Button').css('background-color', '#2E467C');}});$('#notifications').click(function () { return false; });});


    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-37088350-1']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
    (function () {
        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
        po.src = 'https://apis.google.com/js/plusone.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
    })();    
